import argparse
import m5
from m5.objects import Root, SrcClockDomain, VoltageDomain, FiveStagePipeline
p=argparse.ArgumentParser()
p.add_argument('--predict',action='store_true')
p.add_argument('--trace',required=True)
p.add_argument('--iterations',type=int,default=80)
a=p.parse_args()
root=Root(full_system=False)
root.pipeline=FiveStagePipeline(iterations=a.iterations,prediction=a.predict,trace_path=a.trace)
root.pipeline.clk_domain=SrcClockDomain(clock='2GHz',voltage_domain=VoltageDomain(voltage='1V'))
m5.instantiate()
event=m5.simulate()
print('Five-stage exit:',event.getCause(), 'tick:',m5.curTick())
