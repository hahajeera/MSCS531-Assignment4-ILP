from m5.objects.BranchPredictor import ConditionalPredictor
from m5.params import VectorParam
class NoDirectionPrediction(ConditionalPredictor):
    type='NoDirectionPrediction'
    cxx_class='gem5::branch_prediction::NoDirectionPrediction'
    cxx_header='no_direction.hh'
class StaticBackwardPrediction(ConditionalPredictor):
    type='StaticBackwardPrediction'
    cxx_class='gem5::branch_prediction::StaticBackwardPrediction'
    cxx_header='no_direction.hh'
    backward_pcs=VectorParam.Addr([], 'Static PC addresses of backward conditional branches from binary disassembly')
