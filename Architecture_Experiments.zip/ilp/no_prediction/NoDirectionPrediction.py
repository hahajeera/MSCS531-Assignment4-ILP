from m5.objects.BranchPredictor import ConditionalPredictor
class NoDirectionPrediction(ConditionalPredictor):
    type='NoDirectionPrediction'
    cxx_class='gem5::branch_prediction::NoDirectionPrediction'
    cxx_header='no_direction.hh'
