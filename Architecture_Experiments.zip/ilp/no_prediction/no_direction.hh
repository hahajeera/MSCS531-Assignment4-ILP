#ifndef COURSE_NO_DIRECTION_HH
#define COURSE_NO_DIRECTION_HH
#include "cpu/pred/conditional.hh"
#include "params/NoDirectionPrediction.hh"
#include "params/StaticBackwardPrediction.hh"
#include <unordered_set>
namespace gem5 { namespace branch_prediction {
// A non-adaptive fall-through control. BTB/RAS behavior for unconditional
// transfers is retained; this is NOT a stall-until-resolved frontend.
class NoDirectionPrediction : public ConditionalPredictor {
 public:
  NoDirectionPrediction(const NoDirectionPredictionParams &p):ConditionalPredictor(p) {}
  bool lookup(ThreadID, Addr, void *&h) override {h=nullptr;return false;}
  void branchPlaceholder(ThreadID, Addr, bool, void *&h) override {h=nullptr;}
  void updateHistories(ThreadID, Addr, bool, bool, Addr,
      const StaticInstPtr &, void *&) override {}
  void update(ThreadID, Addr, bool, void *&, bool,
      const StaticInstPtr &, Addr) override {}
  void squash(ThreadID, void *&h) override {h=nullptr;}
};
// Direction depends only on the decoded static branch target, not execution
// history. PCs are extracted from the fixed-address ELF disassembly.
class StaticBackwardPrediction : public ConditionalPredictor {
  std::unordered_set<Addr> backward;
 public:
  StaticBackwardPrediction(const StaticBackwardPredictionParams &p):ConditionalPredictor(p),backward(p.backward_pcs.begin(),p.backward_pcs.end()) {}
  bool lookup(ThreadID,Addr pc,void *&h) override {h=nullptr;return backward.count(pc)!=0;}
  void branchPlaceholder(ThreadID,Addr,bool,void *&h) override {h=nullptr;}
  void updateHistories(ThreadID,Addr,bool,bool,Addr,const StaticInstPtr &,void *&) override {}
  void update(ThreadID,Addr,bool,void *&,bool,const StaticInstPtr &,Addr) override {}
  void squash(ThreadID,void *&h) override {h=nullptr;}
};
}}
#endif
