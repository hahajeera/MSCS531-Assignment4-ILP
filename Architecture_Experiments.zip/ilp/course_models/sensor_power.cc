#include "sensor_power.hh"
#include "base/logging.hh"
#include "sim/futex_map.hh"
#include "sim/power_state.hh"
namespace gem5 {
SensorPowerController::SensorPowerController(const SensorPowerControllerParams &p) :
    ClockedObject(p), system(p.system),cpu(p.cpu),handler(p.handler),domain(p.cpu_domain),
    icache(p.icache),dcache(p.dcache),l2(p.l2),itags(p.itags),dtags(p.dtags),
    sleepAddress(p.sleep_address),dmaAddress(p.dma_address),tgid(p.tgid),deadline(p.deadline),
    dmaPort(this,p.system),
    burstEvent([this]{chooseLevel(200000,490000000);},name()+".burst"),
    routineEvent([this]{chooseLevel(10000,50000000);},name()+".routine"),
    sleepEvent([this]{sleep();},name()+".sleep"),
    dmaEvent([this]{startDma();},name()+".dma"),
    writeDone([this]{dmaWritten();},name()+".writeDone"),
    readDone([this]{dmaReadBack();},name()+".readDone"),
    wakeEvent([this]{wake();},name()+".wake"),
    checkEvent([this]{record("dvfs_transition_applied");},name()+".check"),
    trace(p.trace_path) {
    fatal_if(!trace,"Cannot open controller trace");
    for(unsigned i=0;i<source.size();++i) source[i]=(i*7+3)&255;
    trace << "tick,event,level,period_ticks,voltage,cpu_state,l2_state,l1_alloc_ways\n";
}
Port &SensorPowerController::getPort(const std::string &n,PortID i) {
    if(n=="dma") return dmaPort;
    return ClockedObject::getPort(n,i);
}
void SensorPowerController::record(const std::string &e) {
    trace << curTick() << ',' << e << ',' << handler->perfLevel(domain->domainID()) << ','
        << domain->clockPeriod() << ',' << domain->voltage() << ','
        << cpu->powerState->getName() << ',' << l2->powerState->getName() << ','
        << dtags->getWayAllocationMax() << '\n'; trace.flush();
    inform("POWER EVENT %s tick=%u CPU=%s L2=%s ways=%d level=%u",e,curTick(),
        cpu->powerState->getName(),l2->powerState->getName(),dtags->getWayAllocationMax(),handler->perfLevel(domain->domainID()));
}
void SensorPowerController::chooseLevel(uint64_t cycles,Tick budget) {
    unsigned chosen=0;
    for(int level=2;level>=0;--level) {
        if(cycles*handler->clkPeriodAtPerfLevel(domain->domainID(),level)+handler->transLatency()<=budget) {chosen=level;break;}
    }
    handler->perfLevel(domain->domainID(),chosen);
    record("deadline_policy_request_"+std::to_string(chosen));
    if(checkEvent.scheduled()) deschedule(checkEvent);
    schedule(checkEvent,curTick()+handler->transLatency()+1);
}
void SensorPowerController::startup() {
    record("always_on_controller_started");
    schedule(burstEvent,10000000); schedule(routineEvent,100000000);
    schedule(sleepEvent,300000000); schedule(dmaEvent,500000000);
}
void SensorPowerController::sleep() {
    fatal_if(cpu->getContext(0)->status()!=ThreadContext::Suspended,"CPU did not enter sleep before cache gating");
    fatal_if(cpu->powerState->get()!=enums::OFF,"CPU did not reach OFF state");
    // All CPU requests have quiesced. Flush dirty data before limiting ways.
    // Allocation limiting plus invalidation models usable capacity reduction;
    // transistor-level way leakage is intentionally not inferred.
    static_cast<SimObject*>(icache)->memWriteback();
    static_cast<SimObject*>(dcache)->memWriteback();
    static_cast<SimObject*>(l2)->memWriteback();
    static_cast<SimObject*>(icache)->memInvalidate();
    static_cast<SimObject*>(dcache)->memInvalidate();
    static_cast<SimObject*>(l2)->memInvalidate();
    itags->setWayAllocationMax(1); dtags->setWayAllocationMax(1);
    l2->powerState->set(enums::OFF);
    chooseLevel(1000,100000000); record("sleep_cache_way_shutdown_l2_off");
}
void SensorPowerController::startDma() {
    fatal_if(cpu->powerState->get()!=enums::OFF,"DMA test must run with CPU OFF");
    record("dma_write_256_bytes_while_cpu_off");
    dmaPort.dmaAction(MemCmd::WriteReq,dmaAddress,source.size(),&writeDone,source.data(),0);
}
void SensorPowerController::dmaWritten() {
    record("dma_write_complete");
    dmaPort.dmaAction(MemCmd::ReadReq,dmaAddress,returned.size(),&readDone,returned.data(),0);
}
void SensorPowerController::dmaReadBack() {
    fatal_if(source!=returned,"DMA read-back mismatch");
    record("dma_readback_256_bytes_verified");
    l2->powerState->set(enums::ON);
    chooseLevel(2000,5000000);
    schedule(wakeEvent,curTick()+handler->transLatency()+1000);
}
void SensorPowerController::wake() {
    // SE mode has no machine interrupt trap handler. A DMA completion event
    // drives the supported futex wake path; it is an interrupt-controller
    // surrogate, not an architectural RISC-V interrupt or WFI claim.
    int woken=system->futexMap.wakeup(sleepAddress,tgid,1);
    fatal_if(woken!=1,"Wake event did not resume exactly one waiting thread");
    fatal_if(curTick()>=deadline,"Wake missed configured deadline");
    record("completion_event_woke_one_thread");
}
}
