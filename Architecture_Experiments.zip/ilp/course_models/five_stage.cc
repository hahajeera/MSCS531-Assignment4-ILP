#include "five_stage.hh"
#include "base/logging.hh"
#include "sim/sim_exit.hh"
namespace gem5 {
FiveStagePipeline::Stats::Stats(statistics::Group *p) : statistics::Group(p),
    ADD_STAT(cycles, statistics::units::Cycle::get(), "Simulated pipeline cycles"),
    ADD_STAT(retired, statistics::units::Count::get(), "Retired scripted instructions"),
    ADD_STAT(latencyCycles, statistics::units::Cycle::get(), "Total fetch through writeback latency"),
    ADD_STAT(branchStalls, statistics::units::Cycle::get(), "Cycles fetch waits for branch resolution"),
    ADD_STAT(mispredictions, statistics::units::Count::get(), "Static prediction errors"),
    ADD_STAT(dataStalls, statistics::units::Cycle::get(), "Decode RAW interlock cycles"),
    ADD_STAT(memoryStalls, statistics::units::Cycle::get(), "Additional memory service cycles"),
    ADD_STAT(ipc, statistics::units::Rate<statistics::units::Count,statistics::units::Cycle>::get(), "Retired instructions per cycle"),
    ADD_STAT(meanLatency, statistics::units::Cycle::get(), "Mean fetch through writeback cycles") {
    ipc = retired / cycles; meanLatency = latencyCycles / retired;
}
FiveStagePipeline::FiveStagePipeline(const FiveStagePipelineParams &p) : ClockedObject(p),
    cycleEvent([this]{tick();},name()+".cycle"), trace(p.trace_path),
    prediction(p.prediction), memCycles(p.memory_cycles), stats(this) {
    fatal_if(!trace || !p.iterations || !memCycles,"Invalid pipeline configuration");
    // Scripted dynamic loop: independent ALU, dependent ALU, store/load role,
    // independent ALU, and a backward conditional branch. It is a timing
    // teaching model, not an ISA emulator or a replacement for gem5 O3CPU.
    for (unsigned i=0;i<p.iterations;++i) {
        program.push_back({1,-1,false,false,false});
        program.push_back({2,1,false,false,false});
        program.push_back({3,2,true,false,false});
        program.push_back({4,-1,false,false,false});
        program.push_back({-1,-1,false,true,i+1<p.iterations});
    }
    program.push_back({5,-1,false,false,false});
    program.push_back({6,-1,false,false,false});
    trace << "cycle,fetch,decode,execute,memory,writeback,event\n";
}
void FiveStagePipeline::startup() { schedule(cycleEvent,clockEdge(Cycles(1))); }
bool FiveStagePipeline::sourceBusy(int source) const {
    if(source<0) return false;
    for(int s=2;s<5;++s) if(stages[s].index>=0 && program[stages[s].index].dst==source) return true;
    return false;
}
void FiveStagePipeline::tick() {
    ++cycle; ++stats.cycles;
    // Snapshot stage occupancy before the edge; each instruction occupies
    // each distinct stage for at least one full cycle.
    trace << cycle;
    for(const auto &s:stages) trace << ',' << s.index;
    std::string event;
    if(stages[4].index>=0) { ++stats.retired; stats.latencyCycles += cycle-stages[4].fetched+1; stages[4]=Slot{}; }
    if(stages[3].index>=0) {
        if(stages[3].remaining>1) { --stages[3].remaining; ++stats.memoryStalls; }
        else { stages[4]=stages[3]; stages[3]=Slot{}; }
    }
    if(stages[2].index>=0 && stages[3].index<0) {
        auto inst=program[stages[2].index];
        if(inst.branch) {
            branchPending=false;
            if(prediction && !inst.taken) {
                ++stats.mispredictions; event="flush_fetch_decode";
                next=stages[2].index+1; stages[0]=Slot{}; stages[1]=Slot{};
            } else event="branch_resolved";
        }
        stages[3]=stages[2]; stages[3].remaining=inst.memory?memCycles:1; stages[2]=Slot{};
    }
    if(stages[1].index>=0 && stages[2].index<0) {
        if(sourceBusy(program[stages[1].index].src)) { ++stats.dataStalls; }
        else { stages[2]=stages[1]; stages[1]=Slot{}; }
    }
    if(stages[0].index>=0 && stages[1].index<0) { stages[1]=stages[0]; stages[0]=Slot{}; }
    if(!prediction && branchPending) { ++stats.branchStalls; }
    else if(stages[0].index<0 && next<int(program.size())) {
        stages[0]={next,cycle+1,1};
        if(program[next].branch && !prediction) branchPending=true;
        ++next;
    }
    trace << ',' << event << '\n';
    bool empty=true; for(auto &s:stages) empty &= s.index<0;
    if(empty && next==int(program.size())) {
        trace.flush();
        inform("FIVE STAGE TEST OK: retired=%u cycles=%u prediction=%s",program.size(),cycle,prediction?"static BTFNT":"disabled, stall until execute");
        exitSimLoop("five-stage workload completed");
    } else {
        fatal_if(cycle>program.size()*30,"Pipeline deadlock");
        schedule(cycleEvent,clockEdge(Cycles(1)));
    }
}
}
