from m5.objects.ClockedObject import ClockedObject
from m5.params import *

class FiveStagePipeline(ClockedObject):
    type = 'FiveStagePipeline'
    cxx_class = 'gem5::FiveStagePipeline'
    cxx_header = 'five_stage.hh'
    iterations = Param.Unsigned(80, 'Dynamic loop iterations')
    prediction = Param.Bool(False, 'Static backward-taken prediction; false stalls at branches')
    memory_cycles = Param.Unsigned(3, 'Memory operation service cycles')
    trace_path = Param.String('pipeline.csv', 'Cycle-by-cycle stage trace')

class SensorPowerController(ClockedObject):
    type = 'SensorPowerController'
    cxx_class = 'gem5::SensorPowerController'
    cxx_header = 'sensor_power.hh'
    system = Param.System('Memory system')
    cpu = Param.BaseCPU('CPU to wake')
    handler = Param.DVFSHandler('Runtime DVFS handler')
    cpu_domain = Param.SrcClockDomain('Controlled CPU domain')
    icache = Param.Cache('L1 instruction cache')
    dcache = Param.Cache('L1 data cache')
    l2 = Param.Cache('Optional L2 cache')
    itags = Param.BaseTags('L1 instruction tags')
    dtags = Param.BaseTags('L1 data tags')
    sleep_address = Param.Addr('Virtual futex address')
    tgid = Param.Unsigned(100, 'Thread group ID')
    dma_address = Param.Addr(0x02000000, 'Reserved physical DMA test buffer')
    deadline = Param.Latency('700us', 'Processing completion deadline')
    trace_path = Param.String('power.csv', 'Controller event trace')
    dma = RequestPort('Actual gem5 timing DMA port')
