#ifndef COURSE_FIVE_STAGE_HH
#define COURSE_FIVE_STAGE_HH
#include <array>
#include <fstream>
#include <string>
#include <vector>
#include "base/statistics.hh"
#include "params/FiveStagePipeline.hh"
#include "sim/clocked_object.hh"
#include "sim/eventq.hh"
namespace gem5 {
class FiveStagePipeline : public ClockedObject {
    struct Instruction { int dst, src; bool memory, branch, taken; };
    struct Slot { int index = -1; uint64_t fetched = 0; unsigned remaining = 0; };
    std::vector<Instruction> program;
    std::array<Slot,5> stages;
    EventFunctionWrapper cycleEvent;
    std::ofstream trace;
    bool prediction, branchPending = false;
    unsigned memCycles;
    int next = 0;
    uint64_t cycle = 0;
    struct Stats : statistics::Group {
        statistics::Scalar cycles, retired, latencyCycles, branchStalls, mispredictions, dataStalls, memoryStalls;
        statistics::Formula ipc, meanLatency;
        Stats(statistics::Group *parent);
    } stats;
    void tick();
    bool sourceBusy(int source) const;
  public:
    FiveStagePipeline(const FiveStagePipelineParams &p);
    void startup() override;
};
}
#endif
