#ifndef COURSE_SENSOR_POWER_HH
#define COURSE_SENSOR_POWER_HH
#include <array>
#include <fstream>
#include "dev/dma_device.hh"
#include "params/SensorPowerController.hh"
#include "sim/clocked_object.hh"
#include "sim/dvfs_handler.hh"
#include "mem/cache/cache.hh"
#include "mem/cache/tags/base.hh"
#include "cpu/base.hh"
namespace gem5 {
class SensorPowerController : public ClockedObject {
    System *system;
    BaseCPU *cpu;
    DVFSHandler *handler;
    SrcClockDomain *domain;
    Cache *icache, *dcache, *l2;
    BaseTags *itags, *dtags;
    Addr sleepAddress, dmaAddress;
    unsigned tgid;
    Tick deadline;
    DmaPort dmaPort;
    std::array<uint8_t,256> source{}, returned{};
    EventFunctionWrapper burstEvent, routineEvent, sleepEvent, dmaEvent,
        writeDone, readDone, wakeEvent, checkEvent;
    std::ofstream trace;
    void record(const std::string &event);
    void chooseLevel(uint64_t cycles, Tick budget);
    void sleep();
    void startDma();
    void dmaWritten();
    void dmaReadBack();
    void wake();
  public:
    SensorPowerController(const SensorPowerControllerParams &p);
    Port &getPort(const std::string &name, PortID idx=InvalidPortID) override;
    void startup() override;
};
}
#endif
