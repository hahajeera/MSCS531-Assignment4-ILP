#!/bin/bash
set -euo pipefail
base=$(cd "$(dirname "$0")" && pwd)
gem5_root="${GEM5_ROOT:-$HOME/gem5}"
for mode in disabled static; do
  out="$base/results/five_stage/$mode"
  mkdir -p "$out"
  options=(); if [ "$mode" = static ]; then options+=(--predict); fi
  "$gem5_root/build/X86/gem5.opt" -d "$out" "$base/ilp/five_stage_config.py" --trace "$out/pipeline.csv" "${options[@]}" > "$out.log" 2>&1
  grep -q 'FIVE STAGE TEST OK' "$out.log"
done
echo 'Five-stage prediction-disabled and static-prediction tests passed.'
