#!/bin/bash
set -euo pipefail
base=$(cd "$(dirname "$0")" && pwd)
gem5_root="${GEM5_ROOT:-$HOME/gem5}"
cd "$gem5_root"
for isa in X86 RISCV; do
  scons "build/$isa/gem5.opt" -j "${BUILD_JOBS:-6}" "EXTRAS=$base/ilp/no_prediction:$base/ilp/course_models"
done
