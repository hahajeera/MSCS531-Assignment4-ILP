#!/bin/bash
set -euo pipefail
base=$(cd "$(dirname "$0")" && pwd)
gem5_root="${GEM5_ROOT:-$HOME/gem5}"
for mode in disabled static; do
  out="$base/results/five_stage/$mode"
  mkdir -p "$out"
  options=()
  if [ "$mode" = static ]; then options+=(--predict); fi
  "$gem5_root/build/X86/gem5.opt" -d "$out" "$base/ilp/five_stage_config.py" --trace "$out/pipeline.csv" "${options[@]}" > "$out.log" 2>&1
  grep -q 'FIVE STAGE TEST OK' "$out.log"
done
tools="${RISCV_TOOL_DIR:-$HOME/course_tools/extracted/usr/bin}"
if command -v riscv64-linux-gnu-as >/dev/null; then tools=$(dirname "$(command -v riscv64-linux-gnu-as)"); fi
export LD_LIBRARY_PATH="$HOME/course_tools/extracted/usr/lib/x86_64-linux-gnu${LD_LIBRARY_PATH:+:$LD_LIBRARY_PATH}"
"$tools/riscv64-linux-gnu-as" -march=rv32imc -mabi=ilp32 --defsym IDLE_TEST=1 --defsym WAKE_TEST=1 "$base/project/sensor.S" -o "$base/project/sensor_wake.o"
"$tools/riscv64-linux-gnu-ld" -m elf32lriscv -e _start "$base/project/sensor_wake.o" -o "$base/project/sensor_wake"
sleep_addr=$("$tools/riscv64-linux-gnu-nm" "$base/project/sensor_wake" | awk '$3=="idle_word"{print "0x"$1}')
"$tools/riscv64-linux-gnu-objdump" -d "$base/project/sensor_wake" > "$base/project/sensor_wake.disassembly"
python3 "$base/project/branch_map.py" "$base/project/sensor_wake.disassembly" "$base/project/branch_map.json"
out="$base/results/project/runtime_power"
mkdir -p "$out"
"$gem5_root/build/RISCV/gem5.opt" -d "$out" "$base/project/power_config.py" --binary "$base/project/sensor_wake" --sleep-address "$sleep_addr" --branch-map "$base/project/branch_map.json" --trace "$out/power.csv" > "$out.log" 2>&1
grep -q 'SENSOR TEST OK' "$out.log"
grep -q 'WAKE TEST OK' "$out.log"
echo 'All completion experiments passed.'
