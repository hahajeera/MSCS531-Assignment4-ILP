from pathlib import Path
import sys
import csv,json,re
base=Path(__file__).parent
measurements={}
for mode in ['disabled','static']:
    folder=base/'results/five_stage'/mode
    stats={}
    for line in (folder/'stats.txt').read_text().splitlines():
        fields=line.split()
        if len(fields)>1:
            try: stats[fields[0]]=float(fields[1])
            except ValueError: pass
    log=folder.with_suffix('.log').read_text()
    assert 'FIVE STAGE TEST OK' in log
    assert stats['pipeline.retired']==402
    rows=list(csv.DictReader((folder/'pipeline.csv').open()))
    observed={i:[] for i in range(402)}
    for row in rows:
        for stage in ['fetch','decode','execute','memory','writeback']:
            index=int(row[stage])
            if index>=0: observed[index].append((stage,int(row['cycle'])))
    # Every dynamic instruction reaches every distinct stage. Retired work
    # and latency sum are checked independently against the CSV.
    latencies=[]
    for index,events in observed.items():
        for stage in ['fetch','decode','execute','memory','writeback']:
            assert any(s==stage for s,c in events),(mode,index,stage)
        wb=max(c for s,c in events if s=='writeback')
        # Squashed trailing instructions may be fetched again. Use the last
        # fetch occurrence preceding their final retirement.
        fetch_cycles=sorted(c for s,c in events if s=='fetch' and c<=wb)
        starts=[c for i,c in enumerate(fetch_cycles) if i==0 or c>fetch_cycles[i-1]+1]
        fetch=starts[-1]
        latencies.append(wb-fetch+1)
    assert sum(latencies)==stats['pipeline.latencyCycles'],(mode,sum(latencies),stats['pipeline.latencyCycles'])
    if mode=='disabled':
        assert stats['pipeline.mispredictions']==0
        assert stats['pipeline.branchStalls']>0
    else: assert stats['pipeline.mispredictions']==1
    measurements[mode]={k.removeprefix('pipeline.'):v for k,v in stats.items() if k.startswith('pipeline.')}
assert measurements['static']['cycles']<measurements['disabled']['cycles']
if '--pipeline-only' in sys.argv:
    print(json.dumps(measurements,indent=2))
    sys.exit(0)
events=list(csv.DictReader((base/'results/project/runtime_power/power.csv').open()))
applied=[r for r in events if r['event']=='dvfs_transition_applied']
assert {'0','1','2'}<=set(r['level'] for r in applied)
for r in applied:
    assert (int(r['period_ticks']),float(r['voltage']))=={'0':(2000,1.0),'1':(4000,.85),'2':(10000,.7)}[r['level']]
dma=[r for r in events if r['event'].startswith('dma_')]
assert dma and all(r['cpu_state']=='OFF' for r in dma)
assert any(r['event']=='dma_readback_256_bytes_verified' for r in dma)
assert any(r['l2_state']=='OFF' and r['l1_alloc_ways']=='1' for r in events)
wake=next(r for r in events if r['event']=='completion_event_woke_one_thread')
assert wake['cpu_state']=='ON' and wake['l2_state']=='ON'
log=(base/'results/project/runtime_power.log').read_text()
assert 'WAKE TEST OK' in log and 'SENSOR TEST OK' in log
assert 'exiting with last active thread context' in log
measurements['power_events']=events
measurements['validation']='All scripted instructions, independent latency sums, DVFS levels, DMA read-back, OFF-state transfer, cache controls, wake-up, and checksum retention passed.'
(base/'Saved_Assignments/Completion_Measurements.json').write_text(json.dumps(measurements,indent=2))
print(json.dumps(measurements,indent=2))
